import turtle

# setup window 
window = turtle.Screen()
window.title("Ping Pong Game ")
window.setup(width=800, height=600)
window.bgcolor("black")
window.tracer(0)
#score
score = turtle.Turtle()
score.speed(0)
score.color("white")
score.penup()
score.hideturtle()
score.goto(0,250)
score.write("Player_1 : 0 , Player_2 : 0" ,align="center",font=("Courire",24,"bold"))

Player1_score = 0
Player2_score = 0

#player 1
Player1 = turtle.Turtle()
Player1.speed(0)
Player1.shape("square")
Player1.color("blue")
Player1.penup()
Player1.goto(-350, 0)
Player1.shapesize(stretch_wid=5,stretch_len=1)

def Player1_up():
    y = Player1.ycor()
    Player1.sety(y+20)

def Player1_down():
    y = Player1.ycor()
    Player1.sety(y-20)

# Keyboard bindings
window.listen()
window.onkeypress(Player1_up, "Up")
window.onkeypress(Player1_down, "Down")

#player 2
Player2 = turtle.Turtle()
Player2.speed(0)
Player2.shape("square")
Player2.color("red")
Player2.penup()
Player2.goto(350, 0)
Player2.shapesize(stretch_wid=5,stretch_len=1)


def Player2_up():
    y = Player2.ycor()
    Player2.sety(y+20)

def Player2_down():
    y = Player2.ycor()
    Player2.sety(y-20)

# Keyboard bindings
window.listen()
window.onkeypress(Player2_up, "w")
window.onkeypress(Player2_down, "s")


#ball
ball = turtle.Turtle()
ball.speed(0)
ball.shape("circle")
ball.color("white")
ball.penup()
ball.goto(0, 0)

ball.x=-0.5
ball.y=-0.5


while True:
    window.update()
    
    if Player1.ycor() < -250:
        Player1.sety(-250)
    if Player1.ycor() > 250:
        Player1.sety(250)

    if Player2.ycor() < -250:
        Player2.sety(-250)
    if Player2.ycor() > 250:
        Player2.sety(250)
    
    #move the ball to the
    ball.setx(ball.xcor()+ball.x)
    ball.sety(ball.ycor()+ball.y)
  
    #border cheking
    
    #top
    if ball.ycor() > 290:
        ball.sety(290)
        ball.y = ball.y * -1
   
    #bottom
    if ball.ycor() < -290:
        ball.sety(-290)
        ball.y = ball.y * -1  
   
    #left
    if ball.xcor() > 390:
        score.clear()
        ball.setx(390)
        ball.x = ball.x * -1  
        Player2_score+=1
        score.write("Player_1 : {} , Player_2 : {}".format(Player1_score,Player2_score) ,align="center",font=("Courire",24,"bold"))
    #right      
    if ball.xcor() < -390:
        score.clear()
        ball.setx(-390)
        ball.x = ball.x * -1
        Player1_score+=1
        score.write("Player_1 : {} , Player_2 : {}".format(Player1_score,Player2_score) ,align="center",font=("Courire",24,"bold"))
    
        
    #hitting the right paddle
    if ball.xcor() > 340 and ball.xcor()<350 and ball.ycor() < Player2.ycor()+40 and ball.ycor() > Player2.ycor() -40:
        ball.x = ball.x * -1
    
    #hitting the left paddle
    if ball.xcor() < -340 and ball.xcor() > -350 and ball.ycor() < Player1.ycor()+40 and ball.ycor() > Player1.ycor() -40:
        ball.x = ball.x * -1
        
          
Screen.mainloop()

turtle.done()